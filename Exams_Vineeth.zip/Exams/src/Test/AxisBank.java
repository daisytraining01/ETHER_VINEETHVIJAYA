package Test;

public class AxisBank extends BankInfo {

	
	public AxisBank(int customerId, String custName) {
		super(customerId, custName);
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public void deposit()
	{
		System.out.println("this is axisbank deposit acct of "+custName);
	}

}
