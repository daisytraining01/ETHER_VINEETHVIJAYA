//Interface and method overloading concepts :
package Test;

interface EmpDetails
{
	void empId();
	
	
}

public class Employee implements EmpDetails{
	
	public void empId()
	{
		System.out.println("just print");
	}
	
	public void empId(String name,int id)
	{
	 System.out.println("my name is :"+name + " and my id is :"+id);	
	}
	
	public void empId(int sal)
	{
		System.out.println("My salary is :"+sal);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp= new Employee();
		emp.empId();
		emp.empId(1000);
		emp.empId("vineeth", 227);
		EmpDetails ed=new Employee();
		ed.empId();
		
		
		

	}

}
//output:

/*just print
My salary is :1000
my name is :vineeth and my id is :227
just print*/