///fifo and lifo
package Test;

import java.util.ArrayList;
import java.util.Stack;
import java.util.Vector;

public class fifo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> alist=new ArrayList<String>();  
	      alist.add("Steve");
	      alist.add("Tim");
	      alist.add("Lucy");
	      alist.add("Pat");
	      alist.add("Angela");
	      alist.add("Tom");
	  
	      //displaying elements
	      System.out.println(alist);
	  
	      //Adding "Steve" at the fourth position
	      alist.add(3, "Steve");
	  
	      //displaying elements
	      System.out.println(alist);
	      
	      for(String values:alist)
	      {
	    	  System.out.println(values);
	      }
	      System.out.println("*********************************");
	      Stack<String> st=new Stack<String>();
	      st.push("vineeth");
	      st.push("ram");
	      st.push("jithin");
	      st.push("dinesh");
	      System.out.println(st.size());
	      
	      for(int i=0;i<=st.size()+1;i++)
	      {
	      String name=st.pop();
	      System.out.println(name);
	      }
	      
	      
	      

	}

}
