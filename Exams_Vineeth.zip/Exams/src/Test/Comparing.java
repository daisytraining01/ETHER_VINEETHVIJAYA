package Test;

public class Comparing {
	

	    public static void main(String[] args) {

	        String style = "Bold";
	        String style2 = "bold";

	        if(style.equalsIgnoreCase(style2))
	            System.out.println("Equal");
	        else
	            System.out.println("Not Equal");
	    }
	    
	}


