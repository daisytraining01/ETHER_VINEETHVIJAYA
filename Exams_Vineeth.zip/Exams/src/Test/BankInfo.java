//program to demonstrate constructor, encapsulation and Inheritance .
package Test;

public class BankInfo {
	
	private int customerId;
	protected String custName;
	
	public BankInfo(int customerId,String custName  )
	{
		this.customerId=customerId;
		this.custName=custName;
	}
	
	public void saving()
	{
		System.out.println("this is bank info saving acct of "+custName);
	}
	
	public void fixed()
	{
		System.out.println("this is bank info fixed acct of "+custName);
	}
	
	public void deposit()
	{
		System.out.println("this is bank info deposit acct of "+custName);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("**********************");
		BankInfo bi = new BankInfo(227,"sam");
		bi.saving();
		bi.deposit();
		AxisBank ab=new AxisBank(228,"vineeth");
		ab.saving();
		ab.deposit();
		
		BankInfo bi2 = new AxisBank(229,"ram");
		bi2.deposit();
		

	}

}
