package Test;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("****************");
		
		int num=8;
		int a=0,b=1,c=0;
		if(num==1)
		{
			System.out.print(a+" ");
		}
		else
		{
			System.out.print(a+" ");
			System.out.print(b+" ");
			num=num-2;
			while(num>0)
			{
				c=a+b;
				System.out.print(c+" ");
				a=b;
				b=c;
				num--;
				
			}
			
		}
		System.out.println();
		System.out.println("****************");
		

	}

}
