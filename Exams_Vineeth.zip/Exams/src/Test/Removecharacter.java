package Test;

public class Removecharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "REST ASSURED";
		int pos=str.indexOf("ST");
		System.out.println(str.indexOf("ST"));//2
		
		
		
		System.out.println(charRemove(str, pos));
	}

	public static String charRemove(String str, int pos) {
		
		
		return str.substring(0, pos) + str.substring(pos + 2);
		
	}

}
